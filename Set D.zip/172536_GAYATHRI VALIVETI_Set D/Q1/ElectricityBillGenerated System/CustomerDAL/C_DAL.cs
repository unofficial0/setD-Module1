﻿using Customer;
using CustomerException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerDAL
{
    //It is Data Access Layer. Here we write the Logic to Store the Records in Data store.
    public class C_DAL
    {
        static List<C_Entity> CList = new List<C_Entity>();

        public bool AddCustomerDAL(C_Entity c)

        {

            bool CAdded = false;

            try

            {

                CList.Add(c);

                CAdded = true;



            }

            catch (Exception ex)

            {

                throw new C_Exception(ex.Message);

            }

            return CAdded;

        }

       


        public C_Entity SearchCustomerDAL(int searchCID)

        {

            C_Entity searchC = null;

            try

            {



                for (int i = 0; i < CList.Count; i++)

                {

                    C_Entity c = CList[i];

                    if (c.CustomerID == searchCID)

                    {

                        searchC = CList[i];

                        break;

                    }

                }

            }

            catch (Exception ex)

            {

                throw new C_Exception(ex.Message);

            }

            return searchC;

        }

      

    }

}

    

