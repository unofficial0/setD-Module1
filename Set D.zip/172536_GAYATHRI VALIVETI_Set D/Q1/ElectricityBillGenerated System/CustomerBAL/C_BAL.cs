﻿using Customer;
using CustomerDAL;
using CustomerException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerBAL
{
    //It is Business Access Layer
    //Here we are validating the data for Properties provided in Entity Layer .
    //It also acts as Wrapper for CRUD operationds in DAL layer.
    public class C_BAL
    {
        //This the validation part.
        private static bool ValidateCustomer(C_Entity c)

        {

            StringBuilder sb = new StringBuilder();

            bool validCus= true;

            if (c.CustomerID <= 0)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Invalid Customer ID");

            }

            if (c.BillNo <= 0)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Invalid Bill number");

            }

            if (c.CustomerName == string.Empty)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Customer Name Required");

            }

            if (c.MobileNo.Length != 10)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");

            }

            if (validCus == false)

                throw new C_Exception(sb.ToString());

            return validCus;

        }


        public static bool AddCustomerBAL(C_Entity c)

        {

            bool CusAdded = false;

            try

            {

                if (ValidateCustomer(c))

                {

                    C_DAL dal = new C_DAL();

                    CusAdded = dal.AddCustomerDAL(c);

                }

            }

            catch (C_Exception e)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return CusAdded;

        }

       
        public static C_Entity SearchCustomerBAL(int searchCID)

        {

            C_Entity searchCust= null;

            try

            {

                C_DAL dal = new C_DAL();
                searchCust = dal.SearchCustomerDAL(searchCID);

            }

            catch (C_Exception ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return searchCust;

        }

       


    }

}
