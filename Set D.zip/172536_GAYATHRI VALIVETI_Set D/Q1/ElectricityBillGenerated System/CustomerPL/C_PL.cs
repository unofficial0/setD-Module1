﻿using Customer;
using CustomerBAL;
using CustomerException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerPL
{
    class C_PL
    {
        //It is Presentation Layer and also called as User Interface.
        static void Main(string[] args)
        {

            PrintMenu();
            Console.ReadKey();
        }

        private static void PrintMenu() //Print Menu

        {

            string choice1;

            do

            {

                Console.WriteLine("\n***********Electricity Bill Details of Customer ***********");

                Console.WriteLine("1. Add Customer Bill");


                Console.WriteLine("2. Search For Customer Details");

              

                int choice = Int32.Parse(Console.ReadLine());

                switch (choice)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:
                       
                        SearchByCustomerID();

                        break;

                   
                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                choice1 = Console.ReadLine();

            } while ((choice1 == "y"));

          
        }

        private static void AddCustomer() //Add Customer Details

        {

            try

            {

                C_Entity Cust = new C_Entity();





                Console.WriteLine("Enter Bill Number");
                Cust.BillNo = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Customer ID :");
                Cust.CustomerID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Customer Name :");
                Cust.CustomerName = Console.ReadLine();

                Console.WriteLine("Enter PhoneNumber :");
                Cust.MobileNo = Console.ReadLine();

                Console.WriteLine("Enter Address :");
                Cust.Address = Console.ReadLine();

                Console.WriteLine("Enter Email :");                
                Cust.Email= Console.ReadLine();

                Console.WriteLine("Enter Customer Consumed Units :");
                Cust.UnitsConsumed = Convert.ToInt32( Console.ReadLine());

                Console.WriteLine("Enter Rate Per Unit:");
                Cust.Rate = Convert.ToInt32(Console.ReadLine());



                bool custAdded = C_BAL.AddCustomerBAL(Cust);

                if (custAdded)

                    Console.WriteLine("Customer Added");

                else

                    Console.WriteLine("Customer not Added");

            }

            catch (C_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

        }

      
        private static void SearchByCustomerID() // Search Customer Details by Customer ID

        {

            try

            {

                int searchCustID;

                Console.WriteLine("Enter CustomerID to Search:");

                searchCustID = Convert.ToInt32(Console.ReadLine());

                C_Entity searchcust =C_BAL.SearchCustomerBAL(searchCustID);

                if (searchcust != null)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("CustomerID\t\tName\t\tPhoneNumber\t\tAddress\t\tEmailID");

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchcust.CustomerID, searchcust.CustomerName, searchcust.MobileNo, searchcust.Address, searchcust.Email);

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Customer Details Available");

                    Console.ReadLine();

                }

            }

            catch (C_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

        }

       

    }

}
